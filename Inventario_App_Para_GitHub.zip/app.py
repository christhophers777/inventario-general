# Nota: Este script requiere instalar la librería Streamlit.
# Ejecuta `pip install streamlit` si aún no la tienes instalada.

try:
    import streamlit as st
except ModuleNotFoundError:
    raise ImportError("Streamlit no está instalado. Ejecuta 'pip install streamlit' en tu terminal antes de correr esta aplicación.")

import pandas as pd
import numpy as np
import re

# Configuración de la página
st.set_page_config(page_title="Inventario Escuela", layout="wide")

# Título
st.title("Inventario Escuela Casas Viejas")

# Cargar datos desde el Excel
@st.cache_data
def cargar_datos():
    archivo = "Inventario Escuela Casas Viejas SLEP 18-07-2025.xlsx"
    df = pd.read_excel(archivo, sheet_name="Hoja1")
    df = df.fillna("")  # Rellenar vacíos con cadena vacía
    return df

# Cargar datos
df = cargar_datos()

# Filtros
with st.sidebar:
    st.header("Filtros")

    nombre_bien = st.multiselect("Nombre del Bien", sorted(df["NOMBRE DEL BIEN"].unique()))
    marca = st.multiselect("Marca", sorted(df["MARCA"].unique()))
    modelo = st.multiselect("Modelo", sorted(df["MODELO"].unique()))
    estado = st.multiselect("Estado", sorted(df["ESTADO"].unique()))
    ubicacion = st.multiselect("Ubicación", sorted(df["UBICACION"].unique()))

    fecha_min = pd.to_datetime(df["FECHA FACT"], errors='coerce').min()
    fecha_max = pd.to_datetime(df["FECHA FACT"], errors='coerce').max()
    fecha_rango = st.date_input("Rango de Fecha de Factura", [fecha_min, fecha_max])

# Buscador general por palabra clave
busqueda = st.text_input("🔍 Buscar en todas las columnas:").lower()

# Filtrar datos
filtro = df.copy()
if nombre_bien:
    filtro = filtro[filtro["NOMBRE DEL BIEN"].isin(nombre_bien)]
if marca:
    filtro = filtro[filtro["MARCA"].isin(marca)]
if modelo:
    filtro = filtro[filtro["MODELO"].isin(modelo)]
if estado:
    filtro = filtro[filtro["ESTADO"].isin(estado)]
if ubicacion:
    filtro = filtro[filtro["UBICACION"].isin(ubicacion)]

filtro["FECHA FACT"] = pd.to_datetime(filtro["FECHA FACT"], errors='coerce')
filtro = filtro[(filtro["FECHA FACT"] >= pd.to_datetime(fecha_rango[0])) &
                (filtro["FECHA FACT"] <= pd.to_datetime(fecha_rango[1]))]

# Aplicar búsqueda de texto en todas las columnas si hay algo escrito
if busqueda:
    # Filtrar primero
    filtro = filtro[filtro.apply(lambda row: row.astype(str).str.lower().str.contains(busqueda).any(), axis=1)]

    # Resaltar coincidencias
    def resaltar_coincidencias(val):
        val_str = str(val)
        if busqueda in val_str.lower():
            return val_str.replace(busqueda, f"**:orange[{busqueda}]**")
        return val_str

    filtro = filtro.applymap(resaltar_coincidencias)

# Mostrar resultados
st.markdown(f"### Resultados: {len(filtro)} registros encontrados")
st.write(filtro)

# Descargar resultados (sin resaltado)
@st.cache_data
def convertir_csv(df):
    # Quitar resaltado si existe
    df_clean = df.replace(to_replace=r"\*\*:orange\[(.*?)\]\*\*", value=r"\1", regex=True)
    return df_clean.to_csv(index=False).encode("utf-8")

csv = convertir_csv(filtro)
st.download_button(
    label="📂 Descargar resultados como CSV",
    data=csv,
    file_name="inventario_filtrado.csv",
    mime="text/csv",
)

st.markdown("---")
st.caption("Aplicación generada con Streamlit | Inventario Escolar")